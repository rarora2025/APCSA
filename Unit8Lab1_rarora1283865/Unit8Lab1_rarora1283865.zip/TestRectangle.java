
/*
 * @author Rahul Arora
 */

//import scanner
import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//creating new scanner
		Scanner scan = new Scanner(System.in);
		
		//asking user for char
		System.out.print("What character should the rectangle be made out of? ");
		char character = scan.nextLine().toCharArray()[0];
		
		//creating new object Rectangle
		Rectangle rect = new Rectangle(character);
		
		//asking for attributes and setting them
		System.out.print("Enter length of rectangle: ");
		int len = scan.nextInt();
		System.out.print("Enter width of rectangle: ");
		int wid = scan.nextInt();
		rect.setLength(len);
		rect.setWidth(wid);
		
		System.out.println();
		
		//displaying (getting) length and width
		System.out.printf("Length: %d%n", rect.getLength());
		System.out.printf("Width: %d%n", rect.getWidth());
		
		//running methods which compute area and perimeter 
		System.out.printf("Perimeter: %d%n", rect.computePerimeter());
		System.out.printf("Area: %d%n", rect.computeArea());
		
		System.out.println();
		
		//calling method that draws rectangle
		rect.drawRectangle();

	}

}
