/*
 * @author Rahul Arora
 * the blueprint of the Rectangle
 */
public class Rectangle {
	
	
	//defining attributes
	public static int length;
	public static int width;
	public static char character;
	
	

	//constructor which assigns the character
	public Rectangle(char usercharacter) {
		character = usercharacter;
		
	}
	
	//setters
	public static void setLength(int givenlength) {
		if (givenlength >= 1 && givenlength <= 30) {
		length = givenlength;
		} else {
			System.out.println("given length is out of range");
		}
	}
	public static void setWidth(int givenwidth) {
		if (givenwidth >= 1 && givenwidth <= 30) {
			width = givenwidth;
			} else {
				System.out.println("given width is out of range");
			}
	}
	
	//getters
	public static int getLength() {
		return length;
	}
	
	public static int getWidth() {
		return width;
	}

	//method which computers area l*w
	public static int computeArea() {
		return length*width;
	}
	
	//method which computes perimeter 2l+2w
	public static int computePerimeter() {
		return length+length+width+width;
	}
	
	//method that uses while loops to loop through length and width and build rectangle. extended version of for-loop.
	public static void drawRectangle() {
		int i = 1;
		while (i <= length){
			int j = 1;
			while (j <= width) {
				System.out.print(character);
				j++;
				
			}
			System.out.println();
			i++;
			
			
		}
	}
	
	
	
	

}
