
public class Subscriber {

	public void update() {
		System.out.println("Notified of state change");
		
	}

}
