/**
 * This class outputs the string "Hello World."
 * @author Rahul Arora
 */



public class Unit1Activity1 {

	public static void main(String[] args) {
		System.out.println("Hello World.");

	}

}
