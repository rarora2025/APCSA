
public class Pets {
	
	//declaring variables that all Pets need
	protected String name;
	protected int weight;
	protected int age;
	
	//constructor
	public Pets(String name, int weight, int age) {
		this.name = name;
		this.weight = weight;
		this.age = age;
		
	}
	
	//method to be overriden
	public void makeSound() {
		// TODO Auto-generated method stub
		
	}
	
	

}
