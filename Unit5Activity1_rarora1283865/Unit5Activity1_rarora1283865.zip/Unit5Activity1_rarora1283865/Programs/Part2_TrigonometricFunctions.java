/**
 *
 * Converts given angle to radians and displays sine, cosine, and tangent of it  
 * @author Rahul Arora
 * 
 *
 */

import java.util.Scanner;

public class Part2_TrigonometricFunctions {

	public static void main(String[] args) {
		//create new scanner
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter an angle (degrees): ");
		double angle = scan.nextDouble();
		
		//calculating number of radians
		double radians = angle * (Math.PI / 180);
		
		//verifying that the number of radians is equal to: degrees * (pi/180)
		if (radians == Math.toRadians(angle)) {
			System.out.printf("\nYour angle is %f° degrees, and %f radians. \n", angle, radians);
			
			//displaying sine, cosine, and tangent of angle using Math methods
			System.out.printf("The sine of your angle is %f \n", Math.sin(radians));
			System.out.printf("The cosine of your angle is %f \n", Math.cos(radians));
			System.out.printf("The tangent of your angle is %f \n", Math.tan(radians));
		
		} else {
			
			//logic error
			System.out.println("Error converting degrees to radians.");
		
		}
		
		
		
		

	}

}
