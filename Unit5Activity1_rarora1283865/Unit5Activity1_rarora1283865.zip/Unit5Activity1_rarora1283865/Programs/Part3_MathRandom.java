
public class Part3_MathRandom {

	public static void main(String[] args) {
		
		for (int counter = 1; counter <= 20; counter++) {
			int randomNumber = (int) (Math.random() * 5) + 1;
		System.out.println(randomNumber);
		}

	}

}


//test results


/* 
 
experiment 1 results
 
3
2
1
2
4
1
4
1
5
5
1
5
4
5
4
3
5
2
2
5

experiment 2 results

3
3
2
4
1
1
1
2
2
2
3
5
4
2
1
4
5
2
3
5

experiment 3 results

1
2
1
4
3
3
3
4
3
2
4
3
1
5
3
1
2
1
3
5

*/