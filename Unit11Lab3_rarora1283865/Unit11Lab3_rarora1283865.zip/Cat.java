
public class Cat extends Pets {
	
	//constructor
	public Cat(String name, int weight, int age) {
		super(name, weight, age);
		// TODO Auto-generated constructor stub
	}

	//overriden method
	public void makeSound() {
		System.out.println("meow");
	}

}
