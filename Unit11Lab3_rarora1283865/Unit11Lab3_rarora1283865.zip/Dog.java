
public class Dog extends Pets {
	

	public Dog(String name, int weight, int age) {
		super(name, weight, age);
		// TODO Auto-generated constructor stub
	}

	//constructor
	

	//overriden method
	public void makeSound() {
		System.out.println("bow wow");
	}
	
}
