
public class ClassCastExceptionThrow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Object i = Integer.valueOf(2);
		char char1 = (char)i;     
		
	}

}
