
public class NullPointerExceptionThrown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String x = null;
		
		//trying to call a method on an object pointing to nothing (Dereferencing)
		x.charAt(0);

	}

}
