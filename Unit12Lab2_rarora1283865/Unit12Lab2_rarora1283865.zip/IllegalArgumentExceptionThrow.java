import java.util.Random;

public class IllegalArgumentExceptionThrow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Random num = new Random();
	        
	  System.out.println(num.nextInt(0));
		
		
		

	}

}
